/*		driver.c	��������	*/
#include <linux/init.h>
#include <linux/module.h>
#include <linux/types.h>	
#include <linux/fs.h>	
#include <linux/cdev.h>
#define DEV_MAJOR 200
#define DEV_MINOR 0
MODULE_LICENSE("Casm SSDUT/GPL");
static char *buf = "Hello from kernel! \n"; 
static int driver_open( struct inode *driver_inode, struct file *driver_file );
static int driver_release( struct inode *driver_inode, struct file *driver_file );
static ssize_t driver_read( struct file *p_file, char *u_buffer, size_t count, loff_t *ppos );
static ssize_t driver_write( struct file *p_file, char *u_buffer, size_t count, loff_t *ppos );

dev_t driver_dev;
struct cdev *driver_cdev;
struct file_operations driver_fops = 
{
	owner	: THIS_MODULE,
	read	: driver_read,
	open	: driver_open,
	release : driver_release,    
   write :  driver_write,
};
static int driver_open( struct inode *p_inode, struct file *p_file )
{
	return( 0 );
}
static int driver_release( struct inode *p_inode, struct file *p_file )
{
	return( 0 );
}
static ssize_t driver_read( struct file *p_file, char *u_buffer, size_t count, loff_t *ppos )
{
	int rc;
	rc = copy_to_user( u_buffer, buf, count );
	return( rc );
}
static ssize_t driver_write( struct file *p_file, char *u_buffer, size_t count, loff_t *ppos )
{
	int rc;
	rc = copy_from_user( buf,u_buffer,  count );
	return( rc );
}
static int driver_init( void )
{
	int rc;
	driver_dev = MKDEV( DEV_MAJOR, DEV_MINOR );
	rc = register_chrdev_region( driver_dev, 1, "driver" );
	if(rc < 0)
	{
		printk ("Panic! Could not register driver\n");
		return rc;
	}
	driver_cdev = cdev_alloc();
	driver_cdev->owner = THIS_MODULE;
	driver_cdev->ops = &driver_fops;
	cdev_init( driver_cdev, &driver_fops );
	cdev_add( driver_cdev, driver_dev, 1 );
	printk(KERN_ALERT "initial Device Successfully!\n");
	return( 0 );
}
static void driver_exit( void )
{
	cdev_del( driver_cdev );
	unregister_chrdev_region( driver_dev, 1 );
	printk(KERN_ALERT "Exit Device Successfully!\n");
}
module_init(driver_init);
module_exit(driver_exit);
