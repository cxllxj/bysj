/*file:        hello.c*/
/* usage:
        dmesg -c
        make clean
        make
        insmod ./hello.ko
        rmmod ./hello.ko
        dmesg
*/     
#include <linux/init.h>;
#include <linux/module.h>;
#include <linux/kernel.h>;

static int hello_init(void)
{
        printk(KERN_ALERT "Hello,  the crazy computer!\n");
        return 0;
}

static void hello_exit(void)
{
        printk(KERN_ALERT "Bye, the crazy comupter!\n");
}

module_init(hello_init);
module_exit(hello_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("waldner <cxllxj@126.com>;");

