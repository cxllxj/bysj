#include <linux/module.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/net.h>
#include <net/sock.h>
#include <linux/in.h>
#include <linux/types.h>
#include <linux/kthread.h>
#include <linux/wait.h>
#include <linux/skbuff.h>
#include <linux/string.h>
#include <linux/sysctl.h>
#include <linux/netfilter.h>
#include <linux/netfilter_ipv4.h>
#include <asm/checksum.h>
#include <linux/ip.h>
#include <linux/workqueue.h>
#include <linux/jiffies.h>
#include <net/net_namespace.h>
#include <net/route.h>
#include <linux/route.h>
#include <linux/stddef.h>
#include <linux/mutex.h>
#include <linux/neighbour.h>
#include <linux/inet.h>
#include <linux/time.h>
#include <linux/vmalloc.h>
#include <linux/jhash.h>
#include <linux/tcp.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/if_arp.h>
#include <net/ip.h>
#include <net/tcp.h>
#include <net/neighbour.h>
#include <asm/bitops.h>

struct privdev_struct
{
    struct net_device *real_dev;
    
};

static struct net_device *pdev;



static void err(const char *msg)
{
    printk(KERN_ERR "%s failure.\n", msg);
}

int privdev_arp_rcv(struct sk_buff *skb, struct net_device *dev, struct packet_type *ptype, struct net_device *orig_dev)
{
    if (!pskb_may_pull(skb, arp_hdr_len(dev)))
        goto freeskb;

    if (skb->dev == pdev)
        goto out;

    skb->dev = pdev;
    netif_rx(skb);
out:
    return 0;
freeskb:
    kfree_skb(skb);
    return 0;
}

int privdev_ip_rcv(struct sk_buff *skb, struct net_device *dev, struct packet_type *ptype, struct net_device *orig_dev)
{
    if ((skb = skb_share_check(skb, GFP_ATOMIC)) == NULL)
        goto freeskb;

    if (skb->dev == pdev)
        goto out;

    skb->dev = pdev;
    netif_rx(skb);
out:
    return 0;
freeskb:
    kfree_skb(skb);
    return 0;
}

static struct packet_type privdev_arp_pack_type __read_mostly =
{
    .type = cpu_to_be16(ETH_P_ARP),
    .func = privdev_arp_rcv,
};

static struct packet_type privdev_ip_pack_type __read_mostly =
{
    .type = cpu_to_be16(ETH_P_IP),
    .func = privdev_ip_rcv,
};

static int privdev_init(struct net_device *dev)
{
    struct privdev_struct *priv = netdev_priv(dev);
    struct net_device *real_dev = priv->real_dev;

    netif_carrier_off(dev);

    dev->flags = real_dev->flags & ~(IFF_UP | IFF_PROMISC | IFF_ALLMULTI | IFF_MASTER | IFF_SLAVE);
    dev->iflink = real_dev->ifindex;
    dev->state = (real_dev->state & ((1<<__LINK_STATE_NOCARRIER) | (1<<__LINK_STATE_DORMANT))) | (1<<__LINK_STATE_PRESENT);

    dev->features |= real_dev->features;
    dev->gso_max_size = real_dev->gso_max_size;
    dev->dev_id = real_dev->dev_id;
    if (is_zero_ether_addr(dev->dev_addr))
        memcpy(dev->dev_addr, real_dev->dev_addr, dev->addr_len);
    if (is_zero_ether_addr(dev->broadcast))
        memcpy(dev->broadcast, real_dev->broadcast, dev->addr_len);

    return 0;
}

static void privdev_uninit(struct net_device *dev)
{
}

static int privdev_open(struct net_device *dev)
{
    struct privdev_struct *priv = netdev_priv(dev);
    struct net_device *real_dev = priv->real_dev;
    int err;
    
    compare_ether_addr(dev->dev_addr, real_dev->dev_addr);           //chen xiaolong update
    //if (compare_ether_addr(dev->dev_addr, real_dev->dev_addr))
    //{
        //err = dev_uc_add(real_dev, dev->dev_addr);
        //if (err < 0)
        //    goto out;
    //}

    if (dev->flags & IFF_ALLMULTI) 
    {
        err = dev_set_allmulti(real_dev, 1);
        if (err < 0)
            goto del_unicast;
    }
    if (dev->flags & IFF_PROMISC) 
    {
        err = dev_set_promiscuity(real_dev, 1);
        if (err < 0)
            goto clear_allmulti;
    }

    netif_carrier_on(dev);
    return 0;
clear_allmulti:
    if (dev->flags & IFF_ALLMULTI)
        dev_set_allmulti(real_dev, -1);
del_unicast:
    compare_ether_addr(dev->dev_addr, real_dev->dev_addr);            //chen xiaolong update
    //if (compare_ether_addr(dev->dev_addr, real_dev->dev_addr))
        //dev_uc_del(real_dev, dev->dev_addr);
out:
    netif_carrier_off(dev);
    return err;
}

static int privdev_stop(struct net_device *dev)
{
    netif_carrier_off(dev);
    return 0;
}

static void print_iphdr(struct sk_buff *skb)
{
    struct iphdr *iph = ip_hdr(skb);
    unsigned char *sa = (unsigned char *)&iph->saddr;
    unsigned char *da = (unsigned char *)&iph->daddr;

    if (iph->protocol == IPPROTO_TCP)
    {
        printk(KERN_INFO "sa: %d.%d.%d.%d -- da: %d.%d.%d.%d\n", 
            *sa, *(sa+1), *(sa+2), *(sa+3),
            *da, *(da+1), *(da+2), *(da+3));
    }
}

static netdev_tx_t privdev_start_xmit(struct sk_buff *skb, struct net_device *dev)
{
    struct privdev_struct *priv = netdev_priv(dev);
    struct net_device *real_dev = priv->real_dev;
    int ret;
    
    print_iphdr(skb);
    
    //skb_set_dev(skb, real_dev);            //chen xiaolong update
    ret = dev_queue_xmit(skb);
    return ret;
}

static int privdev_ioctl(struct net_device *dev, struct ifreq *ifr, int cmd)
{
    return 0;
}

static int privdev_set_mac_address(struct net_device *dev, void *p)
{
    struct privdev_struct *priv = netdev_priv(dev);
    struct net_device *real_dev = priv->real_dev;
    struct sockaddr *addr = p;
    int err;

    if (!is_valid_ether_addr(addr->sa_data))
        return -EADDRNOTAVAIL;

    if (!(dev->flags & IFF_UP))
        goto out;
    compare_ether_addr(addr->sa_data, real_dev->dev_addr);           //chen xiaolong update
    //if (compare_ether_addr(addr->sa_data, real_dev->dev_addr)) 
    //{
     //   err = dev_uc_add(real_dev, addr->sa_data);
    //    if (err < 0)
    //        return err;
   // }
    compare_ether_addr(dev->dev_addr, real_dev->dev_addr);            //chen xiaolong update
    //if (compare_ether_addr(dev->dev_addr, real_dev->dev_addr))
     //   dev_uc_del(real_dev, dev->dev_addr);
out:
    memcpy(dev->dev_addr, addr->sa_data, ETH_ALEN);
    return 0;
}

static int privdev_neigh_setup(struct net_device *dev, struct neigh_parms *pa)
{
    struct privdev_struct *priv = netdev_priv(dev);
    struct net_device *real_dev = priv->real_dev;
    const struct net_device_ops *ops = real_dev->netdev_ops;
    int err = 0;
    
    if (netif_device_present(real_dev) && ops->ndo_neigh_setup)
        err = ops->ndo_neigh_setup(real_dev, pa);
    
    return err;
}

static struct net_device_stats * privdev_get_stats(struct net_device *dev)
{
    struct net_device_stats *stats = &dev->stats;

    return stats;
}

static void privdev_rx_mode(struct net_device *dev)
{
    struct privdev_struct *priv = netdev_priv(dev);

    dev_mc_sync(priv->real_dev, dev);
    //dev_uc_sync(priv->real_dev, dev);          //chen xiaolong update
}

static struct net_device_ops privdev_ops =
{
    .ndo_init        = privdev_init,
    .ndo_uninit        = privdev_uninit,
    .ndo_open        = privdev_open,
    .ndo_stop        = privdev_stop,
    .ndo_start_xmit        = privdev_start_xmit,
    .ndo_validate_addr    = eth_validate_addr,
    .ndo_do_ioctl        = privdev_ioctl,
    .ndo_set_mac_address    = privdev_set_mac_address,

    .ndo_neigh_setup    = privdev_neigh_setup,
    .ndo_get_stats        = privdev_get_stats,
    .ndo_set_rx_mode    = privdev_rx_mode,
};

static void privdev_setup(struct net_device *dev)
{
    ether_setup(dev);
    
    dev->tx_queue_len     = 1000;
    dev->netdev_ops        = &privdev_ops;
}

static void hold_realdev(struct net_device *dev)
{
    struct privdev_struct *p = netdev_priv(dev);
    struct net_device *real_dev;
    
    if (p == NULL)
    {
        err("netdev_priv return NULL");
        goto out;
    }

    if ((real_dev = dev_get_by_name(&init_net, "eth0")) == NULL)
    {
        err("dev_get_by_name");
        goto out;
    }
    
    p->real_dev = real_dev;
out:
    return;
}

static void release_realdev(struct net_device *dev)
{
    struct privdev_struct *p = netdev_priv(dev);
    
    if (p == NULL)
    {
        err("netdev_priv return NULL");
        goto out;
    }

    dev_put(p->real_dev);
out:
    return;
}

static int __init privdev_register(void)
{
    pdev = alloc_netdev(sizeof(struct privdev_struct), "priv%d", privdev_setup);
    if (pdev == NULL)
    {
        err("alloc_netdev");
        goto out;
    }
    
    dev_net_set(pdev, &init_net);
    hold_realdev(pdev);
    if (register_netdev(pdev) < 0)
    {
        err("register_netdevice");
        goto err;
    }

    dev_add_pack(&privdev_arp_pack_type);
    dev_add_pack(&privdev_ip_pack_type);
    
    printk(KERN_INFO "priv0 register successful.\n");
    return 0;
err:
    release_realdev(pdev);
    free_netdev(pdev);
out:
    return -ENOMEM;
}

static void __exit privdev_unregister(void)
{
    dev_remove_pack(&privdev_ip_pack_type);
    dev_remove_pack(&privdev_arp_pack_type);
    unregister_netdev(pdev);
    release_realdev(pdev);
    free_netdev(pdev);
    printk(KERN_INFO "priv0 unregister successful.\n");
}

module_init(privdev_register);
module_exit(privdev_unregister);
MODULE_LICENSE("GPL");

 


 


